var quiz_body={
    "header_arb":' المخاليط',
    "question_tag":'سيظهر في الشاشة مجموعة من الدبابات قم بتحريك المدفع باتجاه الدبابة التي تحمل الإجابات إلى اليمين واليسار. أطلق الصاروخ في اتجاه الدبابة التي تحمل الإجابة الصحيحة.'
};

var cannon_tank = [
    {
		"questionsTxt":"............. مادَّتان أو أكثر تختلطان معًا. تحافِظُ كلُّ مادَّةٍ في المخلوط على نوعِها.",
		"answers": [
			{
				"trueAnswer": false,
				"answerTxt": "المحلول",
			},
			{
				"trueAnswer": true,
				"answerTxt": "المخلوط",
			},
			{
				"trueAnswer": false,
				"answerTxt": "السبائك",
			},
			{
				"trueAnswer": false,
				"answerTxt": "الترشيح",
			}
		]		
	},
    {
		"questionsTxt":"دروب	............. مخلوطٌ مكوَّنٌ من مادَّتين أو أكثر ممتزجتين معًا امتزاجًا تامًّا.",
		"answers": [
			{
				"trueAnswer": true,
				"answerTxt": "المحلول",
			},
			{
				"trueAnswer": false,
				"answerTxt": "المخلوط",
			},
			{
				"trueAnswer": false,
				"answerTxt": "السبائك",
			},
			{
				"trueAnswer": false,
				"answerTxt": "المرشِّحُ",
			}
		]		
	},
    {
		"questionsTxt":"............. هي تنتجُ عن خلْطِ نوعينِ أو أكثرَ من العناصر أحدُهما على الأقلِّ فلزٌّ.",
		"answers": [
			{
				"trueAnswer": false,
				"answerTxt": "المرشِّحُ",
			},
			{
				"trueAnswer": true,
				"answerTxt": "السبائك",
			},
			{
				"trueAnswer": false,
				"answerTxt": "الترشيح",
			},
			{
				"trueAnswer": false,
				"answerTxt": "المخلوط",
			}
		]		
	},
    {
		"questionsTxt":"............. هي أداةٌ تُستخدَمُ لفصلِ الأشياء بحسب أحجامها.",
		"answers": [
			{
				"trueAnswer": false,
				"answerTxt": "السبائك",
			},
			{
				"trueAnswer": false,
				"answerTxt": "المخلوط",
			},
			{
				"trueAnswer": true,
				"answerTxt": "المرشِّحُ",
			},
			{
				"trueAnswer": false,
				"answerTxt": "الترشيح",
			}
		]		
	},	

   
   
   

    
]	