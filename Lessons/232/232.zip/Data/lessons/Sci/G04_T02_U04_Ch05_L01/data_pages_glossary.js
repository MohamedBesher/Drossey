var pages=
    {
        '0':{
            'name':'Elbazz',
            'title':'المصطلحات',
//            'lesson':'الدرس الاول  ',  
            'tip_msg':'اضغط على كل حرف لتعرض تعريفات المصطلحات التي تبدأ بذلك الحرف. ',
            'terms':[
                { 
                    'word':'المدار',
                    'desc':'<span style="color:blue">هو المسار </span >الدائريّ أو شبه الدائريّ الذي يسلُكُه الجسم المتحرِّك حولَ جسمٍ آخر.',
                    //            'img':'../Player/lessons/Demo/media/pics/6.jpg',
                    //            'video':"../Player/lessons/Demo/video/page3",    
                    //            'slider':[
                    //                '../Player/lessons/Demo/media/pics/6.jpg',
                    //                '../Player/lessons/Demo/media/pics/2.jpg',
                    //                '../Player/lessons/Demo/media/pics/3.jpg',
                    //                '../Player/lessons/Demo/media/pics/4.jpg'
                    //            ]        
                },
                { 
                    'word':'دورة الأرض السنوية  ',
                    'desc':' <span style="color:blue">هي الدورة</span > التي يستغرقُ فيها دورانُ الأرضِ حولَ الشَّمس ٣٦٥٫٢٥ يومًا، أي: سنةً ميلادية واحدة. ',
                    'media':{
//                        'img':'../Player/lessons/Demo/media/pics/11.jpg'
                    }
                    
                },
                { 
                    'word':' المحور  ',
                    'desc':' <span style="color:blue">خطٌّ</span> حقيقيٌّ أو وهميٌّ يدورُ حولَهُ الجسم',
                    'media':{
//                        'video':"../Player/lessons/Demo/video/page3" 
                    }
                },
                { 
                    'word':'دورة الأرض اليومية',
                    'desc':'<span style="color:blue">هي الدورةُ</span > التي تتمُّ فيها الأرض دورةً كاملةً حولَ مِحورِها كلَّ يوم ',
                    'media':{
                        'slider':[
//                            '../Player/lessons/Demo/media/pics/6.jpg',
//                            '../Player/lessons/Demo/media/pics/2.jpg',
//                            '../Player/lessons/Demo/media/pics/3.jpg',
//                            '../Player/lessons/Demo/media/pics/4.jpg'
                        ]   
                    }
                },
                
                { 
                    'word':'خسوف القمر',
                    'desc':'<span style="color:blue">عندما تُلقِي </span >الأرضُ بظلِّها على القمر، ويكونُ ذلك عندما تقعُ الأرضُ بين الشَّمس والقمر، ويَمرُّ القمرُ في منطقةِ ظلِّ الأرض، فيبدو لنا مُعتِمًا.',
                    'media':{
                        'slider':[
//                            '../Player/lessons/Demo/media/pics/6.jpg',
//                            '../Player/lessons/Demo/media/pics/2.jpg',
//                            '../Player/lessons/Demo/media/pics/3.jpg',
//                            '../Player/lessons/Demo/media/pics/4.jpg'
                        ]   
                    }
                },

               
              
              
             
             
            ]
            
        }
    }

