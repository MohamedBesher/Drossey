var pages=
{
'0':{
    'name':'dictionarydrag_drop',
    'number':'20',
    'title':'نشاط   ',
    'article': {
    //    'title': 'اسحب كل كلمة إلى مكانها المناسب. ',
//        'text': 'اسحب كل كلمة إلى مكانها المناسب.'
    },
//    'narration':"sounds/narration",//set nurration name and src without extiontion example "sounds/correctanswer" and put in the folder sounds the sound with mp3 and ogg extention,  
    'tip_msg':'    قم بسحب كل مصطلح إلى مكانه الصحيح.  ',
    'items_data':[
        {
            'word':'المحور',
            'definition':' <span style="color:red">خطٌّ </span >حقيقيٌّ أو وهميٌّ يدورُ حولَهُ الجسم',
//            'sub_narration':"sounds/sub_narration"
        },
        {
            'word':'دورة الأرض اليومية',
            'definition':'<span style="color:red">هي الدورةُ</span > التي تتمُّ فيها الأرض دورةً كاملةً حولَ مِحورِها كلَّ يوم ',
//            'sub_narration':"sounds/sub_narration"
        }, 
        {
            'word':'خسوف القمر ',
            'definition':"<span style='color:red'>عندما تُلقِي</span > الأرضُ بظلِّها على القمر، ويكونُ ذلك عندما تقعُ الأرضُ بين الشَّمس والقمر، ويَمرُّ القمرُ في منطقةِ ظلِّ الأرض، فيبدو لنا مُعتِمًا.",
//            'sub_narration':""
        },
       
    ]
    
}
}
    