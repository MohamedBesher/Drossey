var quiz_body={
    "header_arb":' الأرض والشمس والقمر',
    "question_tag":'سيظهر في الشاشة مجموعة من الدبابات قم بتحريك المدفع باتجاه الدبابة التي تحمل الإجابات إلى اليمين واليسار. أطلق الصاروخ في اتجاه الدبابة التي تحمل الإجابة الصحيحة.'
};

var cannon_tank = [
    {
		"questionsTxt":"دورة الأرض .................... هي الدورة التي تتم فيها الأرض دورة كاملة حول محورها.",
		"answers": [
			{
				"trueAnswer": false,
				"answerTxt": "السنوية",
			},
			{
				"trueAnswer": true,
				"answerTxt": "اليومية",
			},
			{
				"trueAnswer": false,
				"answerTxt": "الشهرية",
			},
			{
				"trueAnswer": false,
				"answerTxt": "الأسبوعية",
			}
		]		
	},
    {
		"questionsTxt":"	..................... خط حقيقي أو وهمى يدور حوله الجسم.",
		"answers": [
			{
				"trueAnswer": true,
				"answerTxt": "المحور",
			},
			{
				"trueAnswer": false,
				"answerTxt": "المركز",
			},
			{
				"trueAnswer": false,
				"answerTxt": "القطر",
			},
			{
				"trueAnswer": false,
				"answerTxt": "الطول",
			}
		]		
	},
    {
		"questionsTxt":" 	فصل.............. يبدأ في 21 مارس حتى 20 يونيو ",
		"answers": [
			{
				"trueAnswer": false,
				"answerTxt": "الشتاء ",
			},
			{
				"trueAnswer": true,
				"answerTxt": "الربيع",
			},
			{
				"trueAnswer": false,
				"answerTxt": "الخريف",
			},
			{
				"trueAnswer": false,
				"answerTxt": "الصيف",
			}
		]		
	},
    {
		"questionsTxt":" 	فصل .............. يبدأ في 21 ديسمبر حتى 20 مارس ",
		"answers": [
			{
				"trueAnswer": true,
				"answerTxt": "الشتاء ",
			},
			{
				"trueAnswer": false,
				"answerTxt": "الربيع",
			},
			{
				"trueAnswer": false,
				"answerTxt": "الخريف",
			},
			{
				"trueAnswer": false,
				"answerTxt": "الصيف",
			}
		]		
	},
  
   
   
   

    
]	